# Icons

Place your extension icons here:
- `icon16.png` - 16x16 pixels
- `icon48.png` - 48x48 pixels  
- `icon128.png` - 128x128 pixels

You can create these icons using any image editor or online icon generator. The icons should represent a clipboard or clipboard manager theme.

For now, the extension will work without icons, but they will appear as default browser icons.

